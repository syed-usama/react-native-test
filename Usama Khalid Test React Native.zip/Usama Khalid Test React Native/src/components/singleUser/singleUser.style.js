import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      marginVertical:5,
        height:100,
        marginHorizontal:10,
        borderRadius:10,
        borderWidth:1,
        borderColor:'grey',
      flexDirection: 'row',
      backgroundColor: '#fff',
      alignItems:'center',
      paddingHorizontal:20,
      elevation:5,
    },
    image:{
        height:50,
        width:50,
        borderRadius:5,
    },
    text:{
        fontSize:18,
        color:'black',
        fontWeight:'500',
        marginLeft:20,
    }
  });