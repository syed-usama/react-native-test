import { StatusBar } from 'expo-status-bar';
import React from 'react';
import styles from './singleUser.style'
import { FlatList, Image, StyleSheet, Text, View } from 'react-native';

export default function SingleUser({user}) {
  console.log('user',user)
  return (
    <View style={styles.container}>
        <Image
        source={{uri:user.picture.medium}}
        style={styles.image}/>
      <Text style={styles.text}>{user.name.first} {user.name.first}</Text>
    </View>
  );
}

