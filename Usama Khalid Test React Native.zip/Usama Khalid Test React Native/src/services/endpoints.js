export async function getUsersData() {
    let data = [];
    await fetch('https://randomuser.me/api/?results=20', {
        method: 'GET'})
        .then(response => response.json())
        .then(response => {
          console.log('response');
          data = response.results
        })
        .catch(error => {
          console.log('Something went wrong' + error);
        });
    return data;
  }