import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    titleText: {
      fontSize: 20,
      fontWeight: 'bold',
    },
    textInput:{
      borderRadius:10,
      borderWidth:1,
      borderColor:'grey',
      margin:10,
      padding:10
    }
  });