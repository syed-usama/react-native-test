import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useState } from 'react';
import styles from './home.style'
import { FlatList, StyleSheet, Text, TextInput, View } from 'react-native';
import SingleUser from '../../components/singleUser/singleUser';
import { getUsersData } from '../../services/endpoints';

export default function Home() {
  const [users , setUsers] = useState([]);
  const [searchText , setSearchText] = useState([]);
  const [SearchUsers , setSearchUsers] = useState([]);
  useEffect(()=>{
    getData()
  },[])
  const getData =async ()=>{
    const data = await getUsersData()
    // console.log(data)
      setSearchUsers(data);
      setUsers(data)
  }
  const searchData =(value)=>{
    let searched = value.toUpperCase();
    var filtered = users.filter((item) => {
      let itemText = item.name.first.toUpperCase();
      if (itemText.includes(searched)) {
        return item;
      }
    })
    setSearchUsers(filtered)
  }
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TextInput
        style={styles.textInput}
        placeholder='Search Users..'
        onChangeText={(value)=> searchData(value)}
        />
      </View>
      <FlatList
      data={SearchUsers}
      renderItem={({item})=> (
        <SingleUser user={item} key={item.id}/>
      )}
      />
    </View>
  );
}

